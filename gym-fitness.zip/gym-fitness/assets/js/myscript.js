
$('.rating-crousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:2
        }
    }
})

// 
const openBtn = document.querySelector('.open-btn');
const closeBtn = document.querySelector('.close-btn');
const offcanvasMenu = document.querySelector('.offcanvas-menu')

openBtn.addEventListener('click', function(e) {
    e.preventDefault();
    offcanvasMenu.classList.add('active');
});

closeBtn.addEventListener('click', function (e) {
    e.preventDefault();
    offcanvasMenu.classList.remove('active');
});

// vedio-sec
document.addEventListener('DOMContentLoaded', function() {
    var thumbnail = document.getElementById('thumbnail');
    var video = document.getElementById('video');
    var playIcon = document.getElementById('play-icon');

    function playVideo() {
        thumbnail.style.display = 'none';
        playIcon.style.display = 'none';
        video.style.display = 'block';
        video.play();
    }

    thumbnail.addEventListener('click', playVideo);
    playIcon.addEventListener('click', playVideo);
});



// 
var count1 = 1;
    var maxCount1 = 5;
    var count2 = 1;
    var maxCount2 = 10;
    var count3 = 1;
    var maxCount3 = 32;
    var count4 = 1;
    var maxCount4 = 4.9;

    function updateCounter1() {
        document.getElementById("count").textContent = count1;
    }

    function updateCounter2() {
        document.getElementById("count2").textContent = count2;
    }

    function updateCounter3() {
        document.getElementById("count3").textContent = count3;
    }

    function updateCounter4() {
        document.getElementById("count4").textContent = count4;
    }

    function autoIncrement1() {
        setTimeout(function () {
            if (count1 < maxCount1) {
                count1++;
                updateCounter1();
                autoIncrement1();
            }
        }, 500);
    }

    function autoIncrement2() {
        setTimeout(function () {
            if (count2 < maxCount2) {
                count2++;
                updateCounter2();
                autoIncrement2();
            }
        }, 100);
    }

    function autoIncrement3() {
        setTimeout(function () {
            if (count3 < maxCount3) {
                count3++;
                updateCounter3();
                autoIncrement3();
            }
        }, 200);
    }

    function autoIncrement4() {
        setTimeout(function () {
            if (count4 < maxCount4) {
                count4++;
                updateCounter4();
                autoIncrement4();
            }
        }, 300);
    }

    autoIncrement1();
    autoIncrement2();
    autoIncrement3();
    autoIncrement4();




// $('.rating-crousel').owlCarousel({
//     loop:true,
//     margin:10,
//     nav:true,
//     items:1,
//     mouseDrag:false,
//     animateOut: 'slideOutUp',
//     animateIn: 'slideInUp',
//     responsive:{
//         0:{
//             items:1
//         },
//         600:{
//             items:1
//         },
//         1000:{
//             items:1
//         }
//     }
// });

// accordian
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    // Close all accordions
    var allAccordions = document.getElementsByClassName("accordion");
    for (var j = 0; j < allAccordions.length; j++) {
      if (allAccordions[j] !== this) { // Skip the clicked accordion
        allAccordions[j].classList.remove("active");
        var panel = allAccordions[j].nextElementSibling;
        panel.style.maxHeight = null;
      }
    }

    // Toggle active class for clicked accordion
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    }
  });
}